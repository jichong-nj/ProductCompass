#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
导入CPGL产品销售数据
"""

import os
import sys
import pandas as pd

# 添加Django项目根目录到Python路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 配置Django环境
import os
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'ProductCompass.settings')
import django
django.setup()

from Products.models import Vendor, Product, ProductModel
from Customers.models import AdminDiv, Customer, CustomerProduct


def insert_cpgl_data():
    """导入CPGL产品销售数据"""
    try:
        # 读取Excel文件
        excel_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "测试.xlsx")
        df = pd.read_excel(excel_path, sheet_name="CP")
        
        # 遍历数据行
        for index, row in df.iterrows():
            row_num = index + 2  # Excel行号从2开始
            
            # 获取行政区划名称
            xzqh_name = row.get("XZQH")
            if not xzqh_name:
                print(f"第{row_num}行：行政区划为空，跳过")
                continue
            
            # 获取CPGL列值（是否销售）
            cpgl_value = row.get("CPGL")
            if cpgl_value != "已完成":
                print(f"第{row_num}行：CPGL列不为√，跳过")
                continue
            
            # 获取厂商名称
            cs_name = row.get("CS")
            if not cs_name:
                print(f"第{row_num}行：厂商为空，跳过")
                continue
            
            # 查找或创建行政区划
            try:
                admin_div = AdminDiv.objects.get(name=xzqh_name)
            except AdminDiv.DoesNotExist:
                print(f"第{row_num}行：行政区划{xzqh_name}不存在，跳过")
                continue
            
            # 查找或创建厂商
            vendor, vendor_created = Vendor.objects.get_or_create(name=cs_name)
            if vendor_created:
                print(f"第{row_num}行：创建新厂商：{cs_name}")
            
            # 查找或创建产品（CPGL）
            product, product_created = Product.objects.get_or_create(
                product_name="CPGL",
                defaults={
                    "product_type": "STANDALONE_SOFTWARE",
                    "product_description": "产品管理系统"
                }
            )
            if product_created:
                print(f"第{row_num}行：创建新产品：CPGL")
            
            # 查找或创建产品型号（默认）
            product_model, model_created = ProductModel.objects.get_or_create(
                product=product,
                model_name="默认",
                defaults={"remark": "默认型号"}
            )
            if model_created:
                print(f"第{row_num}行：创建新产品型号：默认")
            
            # 获取该行政区划下的所有客户
            customers = Customer.objects.filter(admin_div=admin_div)
            
            # 为每个客户创建产品记录
            for customer in customers:
                # 检查是否已存在相同的记录
                existing_record = CustomerProduct.objects.filter(
                    customer=customer,
                    product_model=product_model,
                    vendor=vendor
                ).first()
                
                if not existing_record:
                    # 创建新记录
                    CustomerProduct.objects.create(
                        customer=customer,
                        product_model=product_model,
                        vendor=vendor,
                        quantity=1
                    )
                    print(f"第{row_num}行：为客户{customer.name}创建CPGL产品记录")
                else:
                    print(f"第{row_num}行：客户{customer.name}的CPGL产品记录已存在，跳过")
        
        print("\n数据导入完成！")
        
    except Exception as e:
        print(f"导入数据时出错：{e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    insert_cpgl_data()