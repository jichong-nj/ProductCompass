#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
处理Excel文件数据，导入DJJG产品销售记录
"""

import os
import sys
import pandas as pd

# 添加项目根目录到Python路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 配置Django环境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'ProductCompass.settings')
import django
django.setup()

from Customers.models import AdminDiv, Customer, CustomerProduct
from Products.models import Vendor, Product, ProductModel


def process_excel():
    """
    处理Excel文件数据
    """
    # 读取Excel文件
    excel_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '测试.xlsx')
    
    try:
        # 读取sheet名为"S"的表格数据
        df = pd.read_excel(excel_path, sheet_name='S')
        print(f"成功读取Excel文件，共{len(df)}条数据")
    except Exception as e:
        print(f"读取Excel文件失败：{e}")
        return
    
    # 遍历每条数据
    for index, row in df.iterrows():
        try:
            # 获取XZQH列的值（行政区划名称）
            xzqh_name = row.get('XZQH', '')
            if not xzqh_name:
                print(f"第{index + 2}行：XZQH列为空，跳过")
                continue
            
            # 1. 查找行政区划
            try:
                admin_div = AdminDiv.objects.get(name=xzqh_name)
                print(f"第{index + 2}行：找到行政区划：{admin_div.name}")
            except AdminDiv.DoesNotExist:
                print(f"第{index + 2}行：未找到行政区划：{xzqh_name}")
                continue
            
            # 2. 检查F列内容
            f_column_value = row.get('F', '')
            if f_column_value != '√':
                print(f"第{index + 2}行：F列不为'√'，跳过")
                continue
            
            # 3. 获取E列厂商名称
            vendor_name = row.get('G', '').strip()
            if not vendor_name:
                print(f"第{index + 2}行：E列厂商名称为空，跳过")
                continue
            
            # 4. 查找或创建厂商
            vendor, created = Vendor.objects.get_or_create(name=vendor_name)
            if created:
                print(f"第{index + 2}行：创建了新厂商：{vendor_name}")
            else:
                print(f"第{index + 2}行：找到厂商：{vendor_name}")
            
            # 5. 查找或创建产品（DJJG）
            product, created = Product.objects.get_or_create(
                product_name="DJJG",
                defaults={
                    'product_type': 'STANDALONE_SOFTWARE',  # 假设为单机板软件
                    'product_description': 'DJJG产品'
                }
            )
            if created:
                print(f"第{index + 2}行：创建了新产品：DJJG")
            else:
                print(f"第{index + 2}行：找到产品：DJJG")
            
            # 6. 查找或创建产品型号（默认）
            product_model, created = ProductModel.objects.get_or_create(
                product=product,
                model_name="默认",
                defaults={
                    'remark': '默认型号'
                }
            )
            if created:
                print(f"第{index + 2}行：创建了新产品型号：默认")
            else:
                print(f"第{index + 2}行：找到产品型号：默认")
            
            # 7. 获取该行政区划下的所有客户
            customers = Customer.objects.filter(admin_div=admin_div)
            print(f"第{index + 2}行：该行政区划下共有{len(customers)}个客户")
            
            # 8. 为每个客户创建客户产品采购信息
            for customer in customers:
                # 检查是否已存在相同的客户产品记录
                existing_record = CustomerProduct.objects.filter(
                    customer=customer,
                    product_model=product_model
                ).exists()
                
                if not existing_record:
                    # 创建客户产品采购信息
                    CustomerProduct.objects.create(
                        customer=customer,
                        product_model=product_model,
                        vendor=vendor
                    )
                    print(f"第{index + 2}行：为客户{customer.name}添加了DJJG产品记录")
                else:
                    print(f"第{index + 2}行：客户{customer.name}已存在DJJG产品记录，跳过")
                    
        except Exception as e:
            print(f"处理第{index + 2}行数据时出错：{e}")
            continue


if __name__ == "__main__":
    print("开始处理Excel数据...")
    process_excel()
    print("处理完成！")