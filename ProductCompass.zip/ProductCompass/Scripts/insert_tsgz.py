import os
import sys
import pandas as pd

# 添加项目根目录到Python路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 配置Django环境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'ProductCompass.settings')
import django
django.setup()

from Customers.models import AdminDiv, Customer, CustomerProduct
from Products.models import Vendor, Product, ProductModel

def insert_tsgz_data():
    # 读取Excel文件
    excel_path = os.path.join(os.path.dirname(__file__), '测试.xlsx')
    try:
        df = pd.read_excel(excel_path, sheet_name='S')
        print(f"成功读取Excel文件，共{len(df)}行数据")
    except Exception as e:
        print(f"读取Excel文件失败: {e}")
        return
    
    # 遍历每一行数据
    for index, row in df.iterrows():
        try:
            # 获取XZQH列的值
            xzqh_value = row.get('XZQH', '')
            if not xzqh_value:
                print(f"第{index+2}行：XZQH列为空，跳过")
                continue
            
            # 获取J列的值（TSGZ产品销售情况）
            j_column_value = row.get('J', '')
            if j_column_value != '√':
                print(f"第{index+2}行：J列不是'√'，跳过")
                continue
            
            # 获取K列的值（厂商）
            k_column_value = row.get('K', '')
            if not k_column_value:
                print(f"第{index+2}行：K列（厂商）为空，跳过")
                continue
            
            # 查找或创建厂商
            vendor, created = Vendor.objects.get_or_create(name=k_column_value)
            if created:
                print(f"创建新厂商: {k_column_value}")
            
            # 查找或创建产品（TSGZ）
            product, created = Product.objects.get_or_create(
                product_name="TSGZ",
                defaults={
                    'product_type': 'STANDALONE_SOFTWARE',  # 假设为单机板软件
                    'product_description': 'TSGZ产品'
                }
            )
            if created:
                print(f"第{index + 2}行：创建了新产品：TSGZ")
            else:
                print(f"第{index + 2}行：找到产品：TSGZ")
            
            # 查找或创建产品型号
            product_model, created = ProductModel.objects.get_or_create(
                product=product,
                model_name='默认'
            )
            if created:
                print(f"创建新产品型号: 默认")
            
            # 查找行政区划
            try:
                admin_div = AdminDiv.objects.get(name=xzqh_value)
            except AdminDiv.DoesNotExist:
                print(f"行政区划 '{xzqh_value}' 不存在，跳过")
                continue
            
            # 获取该行政区划下的所有客户
            customers = Customer.objects.filter(admin_div=admin_div)
            if not customers:
                print(f"行政区划 '{xzqh_value}' 下没有客户，跳过")
                continue
            
            # 为每个客户创建客户产品采购信息
            for customer in customers:
                # 检查是否已存在该客户的该产品记录
                existing_cp = CustomerProduct.objects.filter(
                    customer=customer,
                    product_model=product_model,
                    vendor=vendor
                ).exists()
                
                if not existing_cp:
                    CustomerProduct.objects.create(
                        customer=customer,
                        product_model=product_model,
                        vendor=vendor
                    )
                    print(f"第{index + 2}行：为客户 '{customer.name}' 创建TSGZ产品采购记录")
                else:
                    print(f"第{index + 2}行：客户 '{customer.name}' 已有TSGZ产品采购记录，跳过")
                    
        except Exception as e:
            print(f"处理第{index+2}行数据时出错: {e}")
            continue
    
    print("数据导入完成")

if __name__ == "__main__":
    insert_tsgz_data()