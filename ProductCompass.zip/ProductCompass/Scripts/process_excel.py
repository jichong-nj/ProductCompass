import pandas as pd
import os
import sys
import django

# 添加项目根目录到Python路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 设置Django环境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'ProductCompass.settings')
django.setup()

from Customers.models import AdminDiv

def process_excel():
    # 读取Excel文件
    excel_path = os.path.join(os.path.dirname(__file__), '测试.xlsx')
    if not os.path.exists(excel_path):
        print(f"文件不存在: {excel_path}")
        return
    
    # 读取sheet名为"S"的表格
    try:
        df = pd.read_excel(excel_path, sheet_name='S')
    except Exception as e:
        print(f"读取Excel文件失败: {e}")
        return
    
    # 遍历每条数据
    for index, row in df.iterrows():
        try:
            # 获取B列和C列的值
            b_value = str(row.iloc[1])  # B列是第二列，索引为1
            c_value = str(row.iloc[2])  # C列是第三列，索引为2
            
            # 根据C列确定等级
            if c_value == "省级":
                level = 0
            elif c_value == "市级":
                level = 1
            else:
                print(f"第{index+2}行: C列值 '{c_value}' 不是 '省级' 或 '市级'")
                continue
            
            # 查找行政区划
            # 条件1: 等级等于level
            # 条件2: B列是name的子串
            admin_divs = AdminDiv.objects.filter(level=level)
            found = False
            
            for admin_div in admin_divs:
                if b_value in admin_div.name:
                    print(f"{admin_div.name}")
                    found = True
                    break
            
            if not found:
                print(f"第{index+2}行: 未找到符合条件的行政区划")
                
        except Exception as e:
            print(f"处理第{index+2}行时出错: {e}")

if __name__ == "__main__":
    process_excel()