#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
根据行政区划创建对应的单位
"""

import os
import sys
import django

# 添加项目根目录到Python路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 配置Django环境
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'ProductCompass.settings')
django.setup()

from Customers.models import AdminDiv, Customer

def create_orgs_from_admin_div():
    """根据行政区划创建对应的单位"""
    print("开始根据行政区划创建单位...")
    
    # 遍历所有行政区划
    for admin_div in AdminDiv.objects.all():
        # 生成单位名称
        if admin_div.level == 0:
            # 第一级别（省和直辖市）：行政区划名称+保密局
            org_name = f"{admin_div.name}保密局"
        elif admin_div.level == 1:
            org_name = f"{admin_div.name}保密局"
            # if admin_div.name.endswith("区"):
            #     # 第二级别，名称以"区"结尾：上级行政区划+本级行政区划名称+保密局
            #     parent_name = admin_div.parent.name if admin_div.parent else ""
            #     org_name = f"{parent_name}{admin_div.name}保密局"
            # else:
            #     # 第二级别，名称不以"区"结尾：本级行政区划名称+保密局
            #     org_name = f"{admin_div.name}保密局"
        else:
            # 其他级别暂不处理
            continue
        
        # 检查单位是否已存在
        existing_customer = Customer.objects.filter(name=org_name, admin_div=admin_div).first()
        if existing_customer:
            print(f"单位已存在：{org_name}")
        else:
            # 创建单位
            customer = Customer.objects.create(
                name=org_name,
                admin_div=admin_div
            )
            print(f"已创建单位：{org_name}")
    
    print("单位创建完成！")

if __name__ == "__main__":
    create_orgs_from_admin_div()