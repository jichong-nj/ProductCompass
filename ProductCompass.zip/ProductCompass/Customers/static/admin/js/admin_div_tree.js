(function($) {
    $(document).ready(function() {
        const $select = $('#id_admin_div');
        if (!$select.length) return;

        // 初始隐藏二级及以下选项
        $select.find('option').each(function() {
            const $opt = $(this);
            const parentId = $opt.attr('data-parent');
            const level = $opt.text().match(/—+/g)?.[0]?.length || 0;

            // 隐藏二级及以上（level>1）
            if (level > 1) {
                $opt.hide();
            }
        });

        // 点击一级选项（level=1），展开/折叠其子级
        $select.on('change', function() {
            const selectedVal = $(this).val();
            if (!selectedVal) return;

            // 隐藏所有子级，只显示选中一级的子级
            $select.find('option').each(function() {
                const $opt = $(this);
                const parentId = $opt.attr('data-parent');
                const level = $opt.text().match(/—+/g)?.[0]?.length || 0;

                // 仅显示选中一级的二级子级
                if (level === 2 && parentId === selectedVal) {
                    $opt.show();
                } else if (level > 2) {
                    $opt.hide(); // 三级及以上暂不显示（可按需扩展）
                }
            });
        });
    });
})(django.jQuery);